import 'dart:convert';
import 'package:uuid/uuid.dart';
import 'package:sethai/models/message.dart';
import 'package:sethai/services/storage_service.dart';

class MessageService {
  static final MessageService _instance = MessageService._internal();
  factory MessageService() => _instance;
  MessageService._internal();

  final StorageService _storage = StorageService();
  final String _key = 'messages';

  Future<List<Message>> getMessages(String conversationId) async {
    final List<dynamic>? data = await _storage.get<List<dynamic>>(_key);
    if (data == null) return [];
    final List<dynamic> list = data;
    return list
        .map((e) => Message.fromJson(e as Map<String, dynamic>))
        .where((m) => m.conversationId == conversationId)
        .toList()
      ..sort((a, b) => a.timestamp.compareTo(b.timestamp));
  }

  Future<Message> sendMessage({
    required String conversationId,
    required String content,
    required String role,
    String? imageUrl,
    String? fileUrl,
  }) async {
    final now = DateTime.now();
    final message = Message(
      id: const Uuid().v4(),
      conversationId: conversationId,
      content: content,
      role: role,
      imageUrl: imageUrl,
      fileUrl: fileUrl,
      timestamp: now,
      createdAt: now,
      updatedAt: now,
    );

    final List<dynamic>? data = await _storage.get<List<dynamic>>(_key);
    final List<dynamic> list = data ?? [];
    final messages = list.map((e) => Message.fromJson(e as Map<String, dynamic>)).toList();
    messages.add(message);
    await _saveMessages(messages);
    return message;
  }

  Future<void> deleteMessage(String messageId) async {
    final List<dynamic>? data = await _storage.get<List<dynamic>>(_key);
    if (data == null) return;
    final List<dynamic> list = data;
    final messages = list.map((e) => Message.fromJson(e as Map<String, dynamic>)).toList();
    messages.removeWhere((m) => m.id == messageId);
    await _saveMessages(messages);
  }

  Future<void> _saveMessages(List<Message> messages) async {
    await _storage.save(_key, messages.map((m) => m.toJson()).toList());
  }

  Future<String> getAIResponse(String prompt, String aiProvider) async {
    await Future.delayed(const Duration(seconds: 1));
    
    final responses = [
      "That's a great question! Based on my analysis, I'd say that $prompt is quite interesting. Let me break it down for you...",
      "I understand your inquiry about $prompt. Here's what I think: this is a multifaceted topic that requires careful consideration.",
      "Great question! Regarding $prompt, there are several key points to consider. First, we should look at the context...",
      "Thanks for asking! When it comes to $prompt, my analysis suggests that there are multiple perspectives to explore.",
      "Interesting topic! Let me help you understand $prompt better. From what I know, this involves several important factors.",
    ];
    
    return responses[DateTime.now().second % responses.length];
  }
}
