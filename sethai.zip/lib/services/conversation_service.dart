import 'dart:convert';
import 'package:uuid/uuid.dart';
import 'package:sethai/models/conversation.dart';
import 'package:sethai/services/storage_service.dart';

class ConversationService {
  static final ConversationService _instance = ConversationService._internal();
  factory ConversationService() => _instance;
  ConversationService._internal();

  final StorageService _storage = StorageService();
  final String _key = 'conversations';

  Future<List<Conversation>> getConversations(String userId) async {
    final List<dynamic>? data = await _storage.get<List<dynamic>>(_key);
    if (data == null) return [];
    final List<dynamic> list = data;
    return list
        .map((e) => Conversation.fromJson(e as Map<String, dynamic>))
        .where((c) => c.userId == userId)
        .toList()
      ..sort((a, b) => b.lastMessageAt.compareTo(a.lastMessageAt));
  }

  Future<Conversation> createConversation(String userId, String title, String aiProvider) async {
    final now = DateTime.now();
    final conversation = Conversation(
      id: const Uuid().v4(),
      userId: userId,
      title: title,
      aiProvider: aiProvider,
      lastMessageAt: now,
      createdAt: now,
      updatedAt: now,
    );

    final conversations = await getConversations(userId);
    conversations.add(conversation);
    await _saveConversations(conversations);
    return conversation;
  }

  Future<void> updateConversation(Conversation conversation) async {
    final List<dynamic>? data = await _storage.get<List<dynamic>>(_key);
    if (data == null) return;
    final List<dynamic> list = data;
    final conversations = list.map((e) => Conversation.fromJson(e as Map<String, dynamic>)).toList();
    final index = conversations.indexWhere((c) => c.id == conversation.id);
    if (index != -1) {
      conversations[index] = conversation;
      await _saveConversations(conversations);
    }
  }

  Future<void> deleteConversation(String conversationId) async {
    final List<dynamic>? data = await _storage.get<List<dynamic>>(_key);
    if (data == null) return;
    final List<dynamic> list = data;
    final conversations = list.map((e) => Conversation.fromJson(e as Map<String, dynamic>)).toList();
    conversations.removeWhere((c) => c.id == conversationId);
    await _saveConversations(conversations);
  }

  Future<void> _saveConversations(List<Conversation> conversations) async {
    await _storage.save(_key, conversations.map((c) => c.toJson()).toList());
  }
}
