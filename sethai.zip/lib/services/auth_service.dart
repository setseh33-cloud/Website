import 'package:uuid/uuid.dart';
import 'package:sethai/models/user.dart';
import 'package:sethai/services/storage_service.dart';

class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  final StorageService _storage = StorageService();
  User? _currentUser;

  Future<User?> getCurrentUser() async {
    if (_currentUser != null) return _currentUser;
    final userMap = await _storage.get<Map<String, dynamic>>('current_user');
    if (userMap != null) {
      _currentUser = User.fromJson(userMap);
    }
    return _currentUser;
  }

  Future<User> login(String email, String password) async {
    final List<dynamic> users = await _storage.get<List<dynamic>>('users') ?? [];

    Map<String, dynamic>? userMap;
    for (final u in users) {
      if (u is Map<String, dynamic> && u['email'] == email) {
        userMap = u;
        break;
      }
    }

    if (userMap == null) {
      throw Exception('User not found. Please register first.');
    }

    final user = User.fromJson(userMap);
    _currentUser = user;
    await _storage.save('current_user', user.toJson());
    return user;
  }

  Future<User> register(String email, String password, String name) async {
    final List<dynamic> users = await _storage.get<List<dynamic>>('users') ?? [];

    final existingUser = users.any((u) => (u is Map<String, dynamic>) && u['email'] == email);
    if (existingUser) {
      throw Exception('Email already registered');
    }

    final now = DateTime.now();
    final user = User(
      id: const Uuid().v4(),
      email: email,
      // Accept any name string provided by the user (including emojis and symbols)
      name: name,
      createdAt: now,
      updatedAt: now,
    );

    users.add(user.toJson());
    await _storage.save('users', users);
    _currentUser = user;
    await _storage.save('current_user', user.toJson());
    return user;
  }

  Future<void> logout() async {
    _currentUser = null;
    await _storage.delete('current_user');
  }

  bool get isLoggedIn => _currentUser != null;
}
