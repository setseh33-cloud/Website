import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:ui' as ui;
import 'package:google_fonts/google_fonts.dart';
import 'package:sethai/models/conversation.dart';
import 'package:sethai/models/message.dart';
import 'package:sethai/services/message_service.dart';
import 'package:sethai/widgets/message_bubble.dart';
import 'package:file_picker/file_picker.dart';
import 'package:sethai/services/conversation_service.dart';

class ChatScreen extends StatefulWidget {
  final Conversation conversation;

  const ChatScreen({super.key, required this.conversation});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _messageController = TextEditingController();
  final _messageService = MessageService();
  final _scrollController = ScrollController();
  final _conversationService = ConversationService();
  List<Message> _messages = [];
  bool _isLoading = true;
  bool _isSending = false;
  bool _aiTyping = false;
  Conversation? _conversation;
  String? _lastUserPrompt;

  @override
  void initState() {
    super.initState();
    _conversation = widget.conversation;
    _loadMessages();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadMessages() async {
    setState(() => _isLoading = true);
    final messages = await _messageService.getMessages(widget.conversation.id);
    if (mounted) {
      setState(() {
        _messages = messages;
        _isLoading = false;
      });
      _scrollToBottom();
    }
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      Future.delayed(const Duration(milliseconds: 100), () {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      });
    }
  }

  Future<void> _sendMessage({String? imageUrl, String? fileName}) async {
    final content = _messageController.text.trim();
    if (content.isEmpty && imageUrl == null && fileName == null) return;

    setState(() => _isSending = true);
    _messageController.clear();

    final userMessage = await _messageService.sendMessage(
      conversationId: widget.conversation.id,
      content: content.isEmpty
          ? (imageUrl != null ? 'Sent an image' : 'Sent a file${fileName != null ? ': $fileName' : ''}')
          : content,
      role: 'user',
      imageUrl: imageUrl,
      fileUrl: fileName,
    );

    setState(() => _messages.add(userMessage));
    _scrollToBottom();

    // Update conversation metadata (title and timestamp)
    _lastUserPrompt = content;
    await _updateConversationMeta(latestUserText: content.isEmpty ? (imageUrl != null ? 'Image' : (fileName ?? 'File')) : content);

    setState(() => _aiTyping = true);
    final aiResponse = await _messageService.getAIResponse(content.isEmpty ? (fileName ?? 'an attachment') : content, _conversation!.aiProvider);
    
    final assistantMessage = await _messageService.sendMessage(
      conversationId: widget.conversation.id,
      content: aiResponse,
      role: 'assistant',
    );

    if (mounted) {
      setState(() {
        _messages.add(assistantMessage);
        _isSending = false;
        _aiTyping = false;
      });
      _scrollToBottom();
    }
  }

  Future<void> _pickAttachment() async {
    final result = await FilePicker.platform.pickFiles(withData: true);
    if (result == null || result.files.isEmpty) return;
    final file = result.files.single;
    final name = file.name;
    final bytes = file.bytes;
    final ext = (file.extension ?? '').toLowerCase();

    const imageExts = ['png', 'jpg', 'jpeg', 'gif', 'webp'];
    if (bytes != null && imageExts.contains(ext)) {
      final mime = ext == 'png'
          ? 'image/png'
          : (ext == 'jpg' || ext == 'jpeg')
              ? 'image/jpeg'
              : ext == 'gif'
                  ? 'image/gif'
                  : 'image/webp';
      final dataUri = 'data:$mime;base64,' + base64Encode(bytes);
      await _sendMessage(imageUrl: dataUri);
    } else {
      await _sendMessage(fileName: name);
    }
  }

  Future<void> _updateConversationMeta({required String latestUserText}) async {
    final convo = _conversation!;
    final now = DateTime.now();
    var updated = convo.copyWith(
      lastMessageAt: now,
      updatedAt: now,
    );
    if (convo.title == 'New Chat' && latestUserText.isNotEmpty) {
      final title = latestUserText.length > 32 ? latestUserText.substring(0, 32) : latestUserText;
      updated = updated.copyWith(title: title);
    }
    await _conversationService.updateConversation(updated);
    if (mounted) setState(() => _conversation = updated);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFC),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF1A1A2E)),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: _conversation!.aiProvider == 'chatgpt'
                      ? [const Color(0xFF6C63FF), const Color(0xFF4ECDC4)]
                      : [const Color(0xFFFF6B9D), const Color(0xFFFF8E53)],
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                _conversation!.aiProvider == 'chatgpt' ? Icons.chat_bubble : Icons.auto_awesome,
                color: Colors.white,
                size: 18,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _conversation!.title,
                    style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600, color: const Color(0xFF1A1A2E)),
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    _conversation!.aiProvider.toUpperCase(),
                    style: GoogleFonts.inter(fontSize: 11, color: const Color(0xFF8F8F9F)),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) async {
              final updated = _conversation!.copyWith(aiProvider: value);
              await _conversationService.updateConversation(updated);
              if (mounted) setState(() => _conversation = updated);
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'chatgpt', child: Text('Use ChatGPT')),
              PopupMenuItem(value: 'deepseek', child: Text('Use DeepSeek')),
            ],
          ),
        ],
      ),
      body: Stack(
        children: [
          Positioned(
            top: -90,
            left: -70,
            child: _GradientBlob(size: 200, colors: const [Color(0xFF6C63FF), Color(0xFF4ECDC4)]),
          ),
          Positioned(
            bottom: -90,
            right: -70,
            child: _GradientBlob(size: 200, colors: const [Color(0xFFFF6B9D), Color(0xFFFF8E53)]),
          ),
          Column(
            children: [
              Expanded(
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : _messages.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: 80,
                                  height: 80,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: _conversation!.aiProvider == 'chatgpt'
                                          ? [const Color(0xFF6C63FF), const Color(0xFF4ECDC4)]
                                          : [const Color(0xFFFF6B9D), const Color(0xFFFF8E53)],
                                    ),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Icon(
                                    _conversation!.aiProvider == 'chatgpt' ? Icons.chat_bubble : Icons.auto_awesome,
                                    color: Colors.white,
                                    size: 36,
                                  ),
                                ),
                                const SizedBox(height: 24),
                                Text(
                                  'Start a conversation',
                                  style: GoogleFonts.poppins(fontSize: 20, fontWeight: FontWeight.w600, color: const Color(0xFF1A1A2E)),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'Ask me anything!',
                                  style: GoogleFonts.inter(fontSize: 14, color: const Color(0xFF8F8F9F)),
                                ),
                              ],
                            ),
                          )
                        : ListView.builder(
                            controller: _scrollController,
                            itemCount: _messages.length,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            itemBuilder: (context, index) => MessageBubble(message: _messages[index]),
                          ),
              ),
              if (_aiTyping)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF6C63FF), Color(0xFF4ECDC4)],
                          ),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: const Icon(Icons.psychology, color: Colors.white, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20),
                            bottomLeft: Radius.circular(4),
                            bottomRight: Radius.circular(20),
                          ),
                          border: Border.all(color: Color(0xFFF0F0F5)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: const [
                            _Dot(),
                            SizedBox(width: 6),
                            _Dot(),
                            SizedBox(width: 6),
                            _Dot(),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ClipRRect(
                child: BackdropFilter(
                  filter: ui.ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.7),
                      border: const Border(top: BorderSide(color: Color(0xFFEAEAF4))),
                    ),
                    padding: const EdgeInsets.all(16),
                    child: SafeArea(
                      child: Row(
                        children: [
                          IconButton(
                            icon: const Icon(Icons.attach_file, color: Color(0xFF6C63FF)),
                            onPressed: _pickAttachment,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFAFAFC),
                                borderRadius: BorderRadius.circular(24),
                                border: Border.all(color: const Color(0xFFF0F0F5)),
                              ),
                              child: TextField(
                                controller: _messageController,
                                decoration: InputDecoration(
                                  hintText: 'Type your message...',
                                  hintStyle: GoogleFonts.inter(color: const Color(0xFF8F8F9F)),
                                  border: InputBorder.none,
                                ),
                                maxLines: null,
                                textCapitalization: TextCapitalization.sentences,
                                onSubmitted: (_) => _sendMessage(),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          _isSending
                              ? Container(
                                  width: 48,
                                  height: 48,
                                  padding: const EdgeInsets.all(12),
                                  child: const CircularProgressIndicator(strokeWidth: 2),
                                )
                              : IconButton(
                                  icon: Container(
                                    width: 48,
                                    height: 48,
                                    decoration: const BoxDecoration(
                                      gradient: LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF4ECDC4)]),
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Icon(Icons.send, color: Colors.white, size: 20),
                                  ),
                                  onPressed: () => _sendMessage(),
                                ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _GradientBlob extends StatelessWidget {
  final double size;
  final List<Color> colors;
  const _GradientBlob({required this.size, required this.colors});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(size),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 34, sigmaY: 34),
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: colors),
            borderRadius: BorderRadius.circular(size),
          ),
        ),
      ),
    );
  }
}

class _Dot extends StatefulWidget {
  const _Dot();
  @override
  State<_Dot> createState() => _DotState();
}

class _DotState extends State<_Dot> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat();
    _anim = Tween<double>(begin: 0.4, end: 1).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _anim,
      child: Container(
        width: 6,
        height: 6,
        decoration: const BoxDecoration(color: Color(0xFF6C63FF), shape: BoxShape.circle),
      ),
    );
  }
}
