import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'package:google_fonts/google_fonts.dart';
import 'package:sethai/services/auth_service.dart';
import 'package:sethai/models/user.dart';
import 'package:sethai/screens/login_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _authService = AuthService();
  User? _user;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadUser();
  }

  Future<void> _loadUser() async {
    setState(() => _isLoading = true);
    final user = await _authService.getCurrentUser();
    if (mounted) {
      setState(() {
        _user = user;
        _isLoading = false;
      });
    }
  }

  Future<void> _handleLogout() async {
    await _authService.logout();
    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const LoginScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFFF7F7FB), Color(0xFFFFFFFF)],
              ),
            ),
          ),
        ),
        Positioned(
          top: -80,
          left: -60,
          child: _GradientBlob(size: 180, colors: const [Color(0xFF6C63FF), Color(0xFF4ECDC4)]),
        ),
        Positioned(
          bottom: -80,
          right: -60,
          child: _GradientBlob(size: 200, colors: const [Color(0xFFFF6B9D), Color(0xFFFF8E53)]),
        ),
        SafeArea(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ShaderMask(
                          shaderCallback: (bounds) => const LinearGradient(
                            colors: [Color(0xFF1A1A2E), Color(0xFF6C63FF)],
                          ).createShader(bounds),
                          child: Text('Profile', style: GoogleFonts.poppins(fontSize: 28, fontWeight: FontWeight.w800, color: Colors.white)),
                        ),
                        const SizedBox(height: 24),
                        Center(
                          child: Container(
                            width: 100,
                            height: 100,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF4ECDC4)]),
                              borderRadius: BorderRadius.circular(28),
                            ),
                            child: const Icon(Icons.person, color: Colors.white, size: 50),
                          ),
                        ),
                        const SizedBox(height: 20),
                        Center(
                          child: Text(
                            _user?.name ?? 'User',
                            style: GoogleFonts.poppins(fontSize: 24, fontWeight: FontWeight.w600, color: const Color(0xFF1A1A2E)),
                          ),
                        ),
                        const SizedBox(height: 6),
                        Center(
                          child: Text(
                            _user?.email ?? '',
                            style: GoogleFonts.inter(fontSize: 15, color: const Color(0xFF6B6B80)),
                          ),
                        ),
                        const SizedBox(height: 28),
                        _GlassSection(
                          child: Column(
                            children: [
                              _buildInfoRow('Account Created', _formatDate(_user?.createdAt ?? DateTime.now())),
                              const Padding(
                                padding: EdgeInsets.symmetric(vertical: 16),
                                child: Divider(color: Color(0xFFEAEAF4), height: 1),
                              ),
                              _buildInfoRow('Last Updated', _formatDate(_user?.updatedAt ?? DateTime.now())),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        _GlassSection(
                          child: Column(
                            children: [
                              _buildSettingTile(Icons.info_outline, 'About SethAi', () {}),
                              const Divider(color: Color(0xFFEAEAF4), height: 1),
                              _buildSettingTile(Icons.help_outline, 'Help & Support', () {}),
                              const Divider(color: Color(0xFFEAEAF4), height: 1),
                              _buildSettingTile(Icons.privacy_tip_outlined, 'Privacy Policy', () {}),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: _handleLogout,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFFF6B6B),
                              foregroundColor: Colors.white,
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(vertical: 18),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.logout, color: Colors.white, size: 20),
                                const SizedBox(width: 8),
                                Text('Logout', style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.white)),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                        Center(
                          child: Text(
                            'SethAi v1.0.0',
                            style: GoogleFonts.inter(fontSize: 13, color: const Color(0xFF6B6B80)),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
        ),
      ],
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: GoogleFonts.inter(fontSize: 15, color: const Color(0xFF8F8F9F))),
        Text(value, style: GoogleFonts.poppins(fontSize: 15, fontWeight: FontWeight.w600, color: const Color(0xFF1A1A2E))),
      ],
    );
  }

  Widget _buildSettingTile(IconData icon, String title, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Icon(icon, color: const Color(0xFF6C63FF), size: 24),
            const SizedBox(width: 16),
            Expanded(
              child: Text(title, style: GoogleFonts.inter(fontSize: 15, color: const Color(0xFF1A1A2E))),
            ),
            const Icon(Icons.chevron_right, color: Color(0xFF8F8F9F)),
          ],
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    final months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${months[date.month - 1]} ${date.day}, ${date.year}';
  }
}

class _GradientBlob extends StatelessWidget {
  final double size;
  final List<Color> colors;
  const _GradientBlob({required this.size, required this.colors});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(size),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 34, sigmaY: 34),
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: colors),
            borderRadius: BorderRadius.circular(size),
          ),
        ),
      ),
    );
  }
}

class _GlassSection extends StatelessWidget {
  final Widget child;
  const _GlassSection({required this.child});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.7),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFEAEAF4)),
          ),
          child: child,
        ),
      ),
    );
  }
}
