import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'package:google_fonts/google_fonts.dart';
import 'package:sethai/services/auth_service.dart';
import 'package:sethai/services/conversation_service.dart';
import 'package:sethai/models/conversation.dart';
import 'package:sethai/widgets/conversation_card.dart';
import 'package:sethai/widgets/custom_button.dart';
import 'package:sethai/screens/chat_screen.dart';
import 'package:sethai/screens/profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _authService = AuthService();
  final _conversationService = ConversationService();
  List<Conversation> _conversations = [];
  bool _isLoading = true;
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _loadConversations();
  }

  Future<void> _loadConversations() async {
    setState(() => _isLoading = true);
    final user = await _authService.getCurrentUser();
    if (user != null) {
      final conversations = await _conversationService.getConversations(user.id);
      if (mounted) {
        setState(() {
          _conversations = conversations;
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _createNewChat(String provider) async {
    final user = await _authService.getCurrentUser();
    if (user == null) return;

    final conversation = await _conversationService.createConversation(
      user.id,
      'New Chat',
      provider,
    );

    if (mounted) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ChatScreen(conversation: conversation),
        ),
      ).then((_) => _loadConversations());
    }
  }

  void _showNewChatDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Choose AI Provider',
              style: GoogleFonts.poppins(fontSize: 22, fontWeight: FontWeight.w600, color: const Color(0xFF1A1A2E)),
            ),
            const SizedBox(height: 24),
            _buildProviderOption('ChatGPT', 'Fast and intelligent responses', Icons.chat_bubble, 'chatgpt', const Color(0xFF6C63FF)),
            const SizedBox(height: 16),
            _buildProviderOption('DeepSeek', 'Advanced AI reasoning', Icons.auto_awesome, 'deepseek', const Color(0xFFFF6B9D)),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildProviderOption(String name, String description, IconData icon, String provider, Color color) {
    return InkWell(
      onTap: () {
        Navigator.pop(context);
        _createNewChat(provider);
      },
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withValues(alpha: 0.3)),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: Colors.white, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600, color: const Color(0xFF1A1A2E))),
                  Text(description, style: GoogleFonts.inter(fontSize: 13, color: const Color(0xFF8F8F9F))),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: color, size: 18),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _buildChatsPage(),
      const ProfileScreen(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFFAFAFC),
      body: Stack(
        children: [
          // Soft gradient background
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFFF7F7FB), Color(0xFFFFFFFF)],
                ),
              ),
            ),
          ),
          Positioned(
            top: -90,
            left: -60,
            child: _GradientBlob(size: 200, colors: const [Color(0xFF6C63FF), Color(0xFF4ECDC4)]),
          ),
          Positioned(
            bottom: -100,
            right: -60,
            child: _GradientBlob(size: 220, colors: const [Color(0xFFFF6B9D), Color(0xFFFF8E53)]),
          ),
          pages[_selectedIndex],
        ],
      ),
      bottomNavigationBar: ClipRRect(
        child: BackdropFilter(
          filter: ui.ImageFilter.blur(sigmaX: 12, sigmaY: 12),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.7),
              border: const Border(top: BorderSide(color: Color(0xFFEAEAF4))),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildNavItem(Icons.chat_bubble_outline, 'Chat', 0),
                    _buildNavItem(Icons.person_outline, 'Profile', 1),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, int index) {
    final isSelected = _selectedIndex == index;
    return InkWell(
      onTap: () => setState(() => _selectedIndex = index),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF6C63FF).withValues(alpha: 0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: isSelected ? const Color(0xFF6C63FF) : const Color(0xFF8F8F9F), size: 24),
            const SizedBox(height: 4),
            Text(
              label,
              style: GoogleFonts.inter(
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                color: isSelected ? const Color(0xFF6C63FF) : const Color(0xFF8F8F9F),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChatsPage() {
    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ShaderMask(
                        shaderCallback: (bounds) => const LinearGradient(
                          colors: [Color(0xFF1A1A2E), Color(0xFF6C63FF)],
                        ).createShader(bounds),
                        child: Text('SethAi', style: GoogleFonts.poppins(fontSize: 30, fontWeight: FontWeight.w800, color: Colors.white)),
                      ),
                      Text('Your intelligent AI companion', style: GoogleFonts.inter(fontSize: 14, color: const Color(0xFF8F8F9F))),
                    ],
                  ),
                ),
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF4ECDC4)]),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(Icons.psychology, color: Colors.white, size: 24),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: SizedBox(
              width: double.infinity,
              child: CustomButton(
                text: 'New Chat',
                icon: Icons.add,
                onPressed: _showNewChatDialog,
              ),
            ),
          ),
          const SizedBox(height: 24),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _conversations.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.chat_bubble_outline, size: 64, color: Color(0xFFF0F0F5)),
                            const SizedBox(height: 16),
                            Text('No conversations yet', style: GoogleFonts.poppins(fontSize: 18, fontWeight: FontWeight.w600, color: const Color(0xFF8F8F9F))),
                            const SizedBox(height: 8),
                            Text('Start a new chat to get started', style: GoogleFonts.inter(fontSize: 14, color: const Color(0xFF8F8F9F))),
                          ],
                        ),
                      )
                    : ListView.builder(
                        itemCount: _conversations.length,
                        itemBuilder: (context, index) => ConversationCard(
                          conversation: _conversations[index],
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => ChatScreen(conversation: _conversations[index]),
                              ),
                            ).then((_) => _loadConversations());
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}

class _GradientBlob extends StatelessWidget {
  final double size;
  final List<Color> colors;
  const _GradientBlob({required this.size, required this.colors});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(size),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 36, sigmaY: 36),
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: colors),
            borderRadius: BorderRadius.circular(size),
          ),
        ),
      ),
    );
  }
}
