class Conversation {
  final String id;
  final String userId;
  final String title;
  final String aiProvider;
  final DateTime lastMessageAt;
  final DateTime createdAt;
  final DateTime updatedAt;

  Conversation({
    required this.id,
    required this.userId,
    required this.title,
    required this.aiProvider,
    required this.lastMessageAt,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'userId': userId,
    'title': title,
    'aiProvider': aiProvider,
    'lastMessageAt': lastMessageAt.toIso8601String(),
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
  };

  factory Conversation.fromJson(Map<String, dynamic> json) => Conversation(
    id: json['id'] as String,
    userId: json['userId'] as String,
    title: json['title'] as String,
    aiProvider: json['aiProvider'] as String,
    lastMessageAt: DateTime.parse(json['lastMessageAt'] as String),
    createdAt: DateTime.parse(json['createdAt'] as String),
    updatedAt: DateTime.parse(json['updatedAt'] as String),
  );

  Conversation copyWith({
    String? id,
    String? userId,
    String? title,
    String? aiProvider,
    DateTime? lastMessageAt,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => Conversation(
    id: id ?? this.id,
    userId: userId ?? this.userId,
    title: title ?? this.title,
    aiProvider: aiProvider ?? this.aiProvider,
    lastMessageAt: lastMessageAt ?? this.lastMessageAt,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}
