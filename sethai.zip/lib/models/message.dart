class Message {
  final String id;
  final String conversationId;
  final String content;
  final String role;
  final String? imageUrl;
  final String? fileUrl;
  final DateTime timestamp;
  final DateTime createdAt;
  final DateTime updatedAt;

  Message({
    required this.id,
    required this.conversationId,
    required this.content,
    required this.role,
    this.imageUrl,
    this.fileUrl,
    required this.timestamp,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'conversationId': conversationId,
    'content': content,
    'role': role,
    'imageUrl': imageUrl,
    'fileUrl': fileUrl,
    'timestamp': timestamp.toIso8601String(),
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
  };

  factory Message.fromJson(Map<String, dynamic> json) => Message(
    id: json['id'] as String,
    conversationId: json['conversationId'] as String,
    content: json['content'] as String,
    role: json['role'] as String,
    imageUrl: json['imageUrl'] as String?,
    fileUrl: json['fileUrl'] as String?,
    timestamp: DateTime.parse(json['timestamp'] as String),
    createdAt: DateTime.parse(json['createdAt'] as String),
    updatedAt: DateTime.parse(json['updatedAt'] as String),
  );

  Message copyWith({
    String? id,
    String? conversationId,
    String? content,
    String? role,
    String? imageUrl,
    String? fileUrl,
    DateTime? timestamp,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => Message(
    id: id ?? this.id,
    conversationId: conversationId ?? this.conversationId,
    content: content ?? this.content,
    role: role ?? this.role,
    imageUrl: imageUrl ?? this.imageUrl,
    fileUrl: fileUrl ?? this.fileUrl,
    timestamp: timestamp ?? this.timestamp,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}
