# SethAi - Architecture Plan

## Overview
SethAi is a modern AI chat application that integrates with ChatGPT and DeepSeek for answering questions, supports file/image uploads, generates images from prompts, and requires user authentication. The app features a sleek white-themed UI with modern design principles.

## Core Features
1. **Authentication System** - Login/Register with local storage
2. **AI Chat Interface** - Multi-provider chat (ChatGPT, DeepSeek)
3. **Image Generation** - Generate images from text prompts
4. **File Upload** - Upload and share files/images in chat
5. **Conversation History** - Save and manage chat sessions
6. **Profile Management** - User profile and settings

## Technical Architecture

### Data Models (`lib/models/`)
1. **User** - User account information
   - id, email, name, avatarUrl, createdAt, updatedAt
   - toJson, fromJson, copyWith methods

2. **Message** - Chat message structure
   - id, conversationId, content, role (user/assistant), imageUrl, fileUrl, timestamp, createdAt, updatedAt
   - toJson, fromJson, copyWith methods

3. **Conversation** - Chat session
   - id, userId, title, aiProvider (chatgpt/deepseek), lastMessageAt, createdAt, updatedAt
   - toJson, fromJson, copyWith methods

4. **GeneratedImage** - AI-generated image record
   - id, userId, prompt, imageUrl, timestamp, createdAt, updatedAt
   - toJson, fromJson, copyWith methods

### Services (`lib/services/`)
1. **AuthService** - Authentication management
   - login, register, logout, getCurrentUser
   - Local storage for user sessions

2. **ConversationService** - Conversation management
   - createConversation, getConversations, deleteConversation
   - Local storage with sample data

3. **MessageService** - Message handling
   - sendMessage, getMessages, deleteMessage
   - Local storage with sample data

4. **ImageGenerationService** - Image generation
   - generateImage, getGeneratedImages
   - Local storage for history

5. **StorageService** - Local storage wrapper
   - save, get, delete, clear operations

### Screens (`lib/screens/`)
1. **LoginScreen** - User authentication entry point
2. **RegisterScreen** - New user registration
3. **HomeScreen** - Main hub with navigation tabs
4. **ChatScreen** - AI conversation interface
5. **ImageGenerationScreen** - Image generation interface
6. **ProfileScreen** - User profile and settings

### Widgets (`lib/widgets/`)
1. **MessageBubble** - Chat message display component
2. **ConversationCard** - Conversation list item
3. **ImageCard** - Generated image display
4. **CustomTextField** - Styled input field
5. **CustomButton** - Styled button component

### Theme (`lib/theme.dart`)
- Light color scheme with white base
- Modern typography using elegant fonts
- No Material Design patterns
- Generous spacing and clean aesthetics

## Implementation Steps

1. **Setup Dependencies**
   - Add required packages: shared_preferences, image_picker, http, uuid

2. **Create Data Models**
   - Implement User, Message, Conversation, GeneratedImage models
   - Add JSON serialization and copyWith methods

3. **Build Services Layer**
   - StorageService for local data persistence
   - AuthService for user authentication
   - ConversationService and MessageService for chat
   - ImageGenerationService for image generation

4. **Update Theme**
   - Configure light white theme with modern colors
   - Set up elegant typography

5. **Build Reusable Widgets**
   - Create CustomButton, CustomTextField, MessageBubble, etc.

6. **Implement Authentication Screens**
   - LoginScreen with email/password
   - RegisterScreen for new users

7. **Build Main Screens**
   - HomeScreen with bottom navigation
   - ChatScreen with message list and input
   - ImageGenerationScreen with prompt input
   - ProfileScreen with user info

8. **Add Sample Data**
   - Populate services with realistic sample conversations
   - Add sample generated images

9. **Testing & Debugging**
   - Run compile_project to check for errors
   - Fix any issues found

## File Structure
```
lib/
├── main.dart
├── theme.dart
├── models/
│   ├── user.dart
│   ├── message.dart
│   ├── conversation.dart
│   └── generated_image.dart
├── services/
│   ├── storage_service.dart
│   ├── auth_service.dart
│   ├── conversation_service.dart
│   ├── message_service.dart
│   └── image_generation_service.dart
├── screens/
│   ├── login_screen.dart
│   ├── register_screen.dart
│   ├── home_screen.dart
│   ├── chat_screen.dart
│   ├── image_generation_screen.dart
│   └── profile_screen.dart
└── widgets/
    ├── message_bubble.dart
    ├── conversation_card.dart
    ├── image_card.dart
    ├── custom_text_field.dart
    └── custom_button.dart
```

## Notes
- Free for all users (no payment integration needed)
- Local storage for MVP (no backend required)
- Modern, sleek UI avoiding Material Design
- Focus on elegant white theme with beautiful colors
